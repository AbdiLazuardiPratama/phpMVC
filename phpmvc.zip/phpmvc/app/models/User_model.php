<?php 

class User_model {
	private $nama = 'Abdi';

	public function getUser()
	{
		return $this->nama;
	}
}	
?>
