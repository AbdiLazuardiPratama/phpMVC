<div class="container">
	<h1 class="mt-4">About me!</h1>
	<img src="<?= BASEURL; ?>/img/Bardock.png" alt="Abdi Lazuardi" width="200" class="rounded-circle shadow" >
	<p>Halo, nama saya <?= $data['nama']; ?>, saya seorang <?= $data['pekerjaan']; ?>, umur saya <?= $data['umur']; ?> tahun</p> 
</div>